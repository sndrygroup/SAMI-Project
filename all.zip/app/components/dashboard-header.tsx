"use client";
import React from "react";
import { signOut } from "next-auth/react";
import { LogOut, ChevronDown } from "lucide-react";
import { Session } from "next-auth";

export function DashboardHeader({ user }: { user: Session["user"] }) {
  return (
    <header className="h-20 border-b border-white/5 flex items-center justify-between px-8 bg-[#111015]/50 backdrop-blur-xl">
      <div>
        {/* Can add breadcrumbs or page title here later */}
      </div>
      <div className="flex items-center gap-4">
        <span className="font-bold">{user?.name}</span>
        <button 
          onClick={() => signOut({ callbackUrl: '/' })} 
          className="p-2 rounded-full text-gray-400 hover:bg-white/10 hover:text-white transition-all"
          title="Sign Out"
        >
          <LogOut size={18} />
        </button>
      </div>
    </header>
  );
}
