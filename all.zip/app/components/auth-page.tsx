"use client";
import { useState } from "react";
import { motion } from "framer-motion";
import { Mail, Lock, ArrowRight, Github } from "lucide-react";

export default function AuthPage({ onLogin }: { onLogin: () => void }) {
  const [mode, setMode] = useState<"login" | "signup">("login");

  return (
    <div className="min-h-screen bg-[#030303] text-white flex items-center justify-center p-6 font-sans" dir="rtl">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full space-y-8"
      >
        {/* الشعار */}
        <div className="text-center">
          <h1 className="text-6xl font-black italic tracking-tighter mb-2">
            SAM<span className="text-purple-500">I</span>
          </h1>
          <p className="text-gray-500 text-sm">
            {mode === "login" ? "مرحباً بعودتك إلى مستقبل الإعلانات" : "أنشئ حسابك وابدأ إدارة حملاتك بذكاء"}
          </p>
        </div>

        {/* أزرار الدخول السريع */}
        <div className="grid grid-cols-2 gap-4">
          <button className="flex items-center justify-center gap-2 py-3 px-4 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 transition-all font-bold text-xs">
            <img src="https://www.google.com/favicon.ico" className="w-4 h-4" alt="Google" />
            قوقل
          </button>
          <button className="flex items-center justify-center gap-2 py-3 px-4 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 transition-all font-bold text-xs">
            <img src="https://www.apple.com/favicon.ico" className="w-4 h-4" alt="Apple" />
            أبل
          </button>
        </div>

        <div className="relative py-4">
          <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-white/5"></span></div>
          <div className="relative flex justify-center text-xs uppercase"><span className="bg-[#030303] px-2 text-gray-600">أو عبر البريد</span></div>
        </div>

        {/* نموذج الدخول */}
        <div className="space-y-4">
          <div className="relative">
            <Mail className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input 
              type="email" 
              placeholder="البريد الإلكتروني" 
              className="w-full bg-[#0d0d0d] border border-white/10 rounded-2xl py-4 pr-12 pl-4 outline-none focus:border-purple-500 transition-all text-sm"
            />
          </div>
          <div className="relative">
            <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input 
              type="password" 
              placeholder="كلمة المرور" 
              className="w-full bg-[#0d0d0d] border border-white/10 rounded-2xl py-4 pr-12 pl-4 outline-none focus:border-purple-500 transition-all text-sm"
            />
          </div>
          
          <button 
            onClick={onLogin}
            className="w-full bg-purple-600 py-4 rounded-2xl font-bold hover:bg-purple-500 transition-all flex items-center justify-center gap-2 shadow-xl shadow-purple-900/20"
          >
            {mode === "login" ? "تسجيل الدخول" : "إنشاء حساب جديد"}
            <ArrowRight size={18} className="rotate-180" />
          </button>
        </div>

        {/* التبديل بين الدخول والتسجيل */}
        <p className="text-center text-sm text-gray-500">
          {mode === "login" ? "ليس لديك حساب؟" : "لديك حساب بالفعل؟"}
          <button 
            onClick={() => setMode(mode === "login" ? "signup" : "login")}
            className="text-purple-400 font-bold mr-2 hover:underline"
          >
            {mode === "login" ? "سجل الآن" : "سجل دخولك"}
          </button>
        </p>
      </motion.div>
    </div>
  );
}