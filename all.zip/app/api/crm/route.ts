// app/api/crm/route.ts
import { NextResponse } from 'next/server';

export async function GET() {
  // جلب العملاء من قاعدة البيانات
  return NextResponse.json([
    { id: '1', name: 'محمد علي', email: 'm@example.com', status: 'new' },
    { id: '2', name: 'سارة أحمد', email: 's@example.com', status: 'closed' },
  ]);
}