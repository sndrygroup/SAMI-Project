import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { amount } = await req.json();
    const amountFloat = parseFloat(amount);

    if (!amountFloat || amountFloat <= 0) {
      return NextResponse.json({ error: "Invalid deposit amount" }, { status: 400 });
    }

    const result = await prisma.$transaction(async (tx) => {
      // 1. Add funds to user's wallet
      const updatedUser = await tx.user.update({
        where: { id: session.user.id },
        data: { adWalletBalance: { increment: amountFloat } },
      });

      // 2. Create a transaction record
      const newTransaction = await tx.transaction.create({
        data: {
          amount: amountFloat,
          type: "DEPOSIT",
          userId: session.user.id,
        },
      });
      
      return { updatedUser, newTransaction };
    });

    return NextResponse.json(result, { status: 200 });

  } catch (error) {
    console.error("Deposit error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
