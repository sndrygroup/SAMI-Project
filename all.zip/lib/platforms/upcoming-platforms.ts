// هذا الملف يجمع المنصات التي ستتوفر قريباً في SAMI
export const upcomingProvider = async (platformName: string) => {
  return { 
    success: false, 
    message: `منصة ${platformName} ستكون متاحة قريباً في الإصدار القادم لسامي.` 
  };
};